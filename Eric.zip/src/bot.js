const LineConnect = require('./connect');
const LINE = require('./main.js');
console.info("\n\Eric bot sl3");
console.info("\n\
=========================================\n\
BotName: Eric sl3 bot\n\
Version: 0.1.1\n\
Thanks to Eric beloved off team\n\
=========================================\n\
\nNOTE : This bot is made by Eric\n\
***𝐆odFàther’z🎴.***");

/*
| This constant is for auth/login
| 
| Change it to your authToken / your email & password
*/
const auth = {
	authToken: '',
	certificate: '',
	email: 'ksamr09@gmail.com',
	password: 'ssaa1122'
}

let client =  new LineConnect();
//let client =  new LineConnect(auth);

client.startx().then(async (res) => {
	while(true) {
		try {
			ops = await client.fetchOps(res.operation.revision);
		} catch(error) {
			console.log('error',error)
		}
		for (let op in ops) {
			if(ops[op].revision.toString() != -1){
				res.operation.revision = ops[op].revision;
				LINE.poll(ops[op])
			}
		}
		//LINE.aLike() //AutoLike (CAUSE LAG)
	}
});
